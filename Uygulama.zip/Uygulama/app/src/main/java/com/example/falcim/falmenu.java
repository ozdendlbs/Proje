package com.example.falcim;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class falmenu extends AppCompatActivity
{
    Button foto,fotobir,fotoiki,izin;
    ImageView goster,gosterbir,gosteriki;
    static int IMAGE =100;
    static int IMAGEBİR =100;
    static int IMAGEİKİ =100;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS =1905;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.falmenu);

        goster=(ImageView) findViewById(R.id.goster);
        foto=(Button)findViewById(R.id.falmenuekle);
        gosterbir=(ImageView) findViewById(R.id.gosterbir);
        fotobir=(Button)findViewById(R.id.falmenueklebir);
        gosteriki=(ImageView) findViewById(R.id.gosteriki);
        fotoiki=(Button)findViewById(R.id.falmenuekleiki);

        foto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(a,IMAGE);
            }
        });

        fotobir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(a,IMAGEBİR);
            }
        });

        fotoiki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(a,IMAGEİKİ);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        if(requestCode==IMAGE)
        {
            super.onActivityResult(requestCode, resultCode, data);
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");
            goster.setImageBitmap(bitmap);
        }

        if (requestCode==IMAGEBİR)
        {
            super.onActivityResult(requestCode, resultCode, data);
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");
            gosterbir.setImageBitmap(bitmap);
        }

        if(requestCode==IMAGEİKİ)
        {
            super.onActivityResult(requestCode, resultCode, data);
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");
            gosteriki.setImageBitmap(bitmap);
        }
    }



}
