package com.example.falcim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class burcmenu extends AppCompatActivity
{

        Button yengec,koc,boga,ikizler,aslan,basak,terazi,akrep,yay,oglak,kova,balık;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.burc);




        yengec=(Button)findViewById(R.id.btnyengec);
        koc=(Button)findViewById(R.id.btnkoc);
        boga=(Button)findViewById(R.id.btnboga);
        ikizler=(Button)findViewById(R.id.btnikizler);
        aslan=(Button)findViewById(R.id.btnaslan);
        basak=(Button)findViewById(R.id.btnbasak);
        terazi=(Button)findViewById(R.id.btnterazi);
        akrep=(Button)findViewById(R.id.btnakrep);
        yay =(Button)findViewById(R.id.btnyay);
        oglak=(Button)findViewById(R.id.btnoglak);
        kova=(Button)findViewById(R.id.btnkova);
        balık=(Button)findViewById(R.id.btnbalık);

        yengec.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.yengec);
            }
        });
        koc.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.koc);
            }
        });
        boga.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.boga);
            }
        });
        ikizler.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.ikizler);
            }
        });
        aslan.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.aslan);
            }
        });
        basak.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.basak);
            }
        });
        terazi.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.terazi);
            }
        });
        akrep.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.akrep);
            }
        });
        yay.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.yay);
            }
        });
        oglak.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.oglak);
            }
        });
        kova.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.kova);
            }
        });
        balık.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setContentView(R.layout.balik);
            }
        });

    }
}
