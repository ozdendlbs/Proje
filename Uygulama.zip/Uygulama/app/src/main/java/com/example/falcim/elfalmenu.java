package com.example.falcim;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class elfalmenu extends AppCompatActivity
{
    Button foto,fotobir,izin;
    ImageView goster,gosterbir;
    static int IMAGE =100;
    static int IMAGEBİR =100;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.elfali);

        foto=(Button)findViewById(R.id.elfalbutonbir);
        goster=(ImageView) findViewById(R.id.goster);
        fotobir=(Button)findViewById(R.id.elfalbutoniki);
        gosterbir=(ImageView) findViewById(R.id.gosterbir);
        izin=(Button)findViewById(R.id.elfalbutonbir);

        foto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(a,IMAGE);
            }
        });

        fotobir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(a,IMAGEBİR);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        if(requestCode==IMAGE)
        {
            super.onActivityResult(requestCode, resultCode, data);
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");
            goster.setImageBitmap(bitmap);
        }


        if (requestCode==IMAGEBİR)
        {
            super.onActivityResult(requestCode, resultCode, data);
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");
            gosterbir.setImageBitmap(bitmap);
        }
    }

}
