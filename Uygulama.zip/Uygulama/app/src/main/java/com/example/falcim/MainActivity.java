package com.example.falcim;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.RadioButton;
import android.widget.ImageView;
import android.widget.VideoView;

import java.net.Inet4Address;

public class MainActivity extends AppCompatActivity
{
    RadioButton bir;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        final Button tarot,kahvefal,kahveel,kahveburc,kahveask;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        kahvefal=(Button)findViewById(R.id.falmenu);
        kahveel=(Button)findViewById(R.id.elfalmenu);
        kahveburc=(Button)findViewById(R.id.burcmenu);
        kahveask=(Button)findViewById(R.id.askmenu);


        kahvefal.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent a =  new  Intent(getApplicationContext(),falmenu.class);
                startActivity(a);
                overridePendingTransition(R.anim.in, R.anim.out);
                overridePendingTransition(R.anim.sag, R.anim.sol);

            }
        });
        kahveel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent a =  new  Intent(getApplicationContext(),elfalmenu.class);
                startActivity(a);
                overridePendingTransition(R.anim.in, R.anim.out);
                overridePendingTransition(R.anim.sag, R.anim.sol);
            }
        });
        kahveburc.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent a =  new  Intent(getApplicationContext(),burcmenu.class);
                startActivity(a);
                overridePendingTransition(R.anim.in, R.anim.out);
                overridePendingTransition(R.anim.sag, R.anim.sol);
            }
        });
        kahveask.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent a =  new  Intent(getApplicationContext(),askmenu.class);
                startActivity(a);
                overridePendingTransition(R.anim.in, R.anim.out);
                overridePendingTransition(R.anim.sag, R.anim.sol);
            }
        });
        tarot=(Button)findViewById(R.id.tarotfal);
        tarot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tarot.setText("ÇOK YAKINDA");
            }
        });

        

    }
}

